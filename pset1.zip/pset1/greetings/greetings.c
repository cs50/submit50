#include <stdio.h>

int main(void)
{
    printf("greetings, all\n");
}